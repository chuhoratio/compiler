package decaf.machdesc;

import decaf.tac.Temp;

public abstract class Register {

	public Temp var;

	public abstract String toString();
}
